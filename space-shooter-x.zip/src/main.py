import pygame
import sys
import random

# Initialize Pygame
pygame.init()
pygame.mixer.init()

# Screen settings
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Space Shooter X")

# Colors
WHITE = (255, 255, 255)
RED = (255, 0, 0)
BLACK = (0, 0, 0)

# Load assets (use placeholder rectangles and sounds for now)
PLAYER_WIDTH, PLAYER_HEIGHT = 50, 40
ENEMY_WIDTH, ENEMY_HEIGHT = 40, 30
BULLET_WIDTH, BULLET_HEIGHT = 5, 10

# Clock and font
clock = pygame.time.Clock()
FPS = 60
font = pygame.font.SysFont("Arial", 20)


class Player:
    def __init__(self):
        self.rect = pygame.Rect(WIDTH // 2, HEIGHT - 60, PLAYER_WIDTH, PLAYER_HEIGHT)
        self.speed = 6
        self.health = 3
        self.bullets = []

    def move(self, keys):
        if keys[pygame.K_LEFT] and self.rect.left > 0:
            self.rect.x -= self.speed
        if keys[pygame.K_RIGHT] and self.rect.right < WIDTH:
            self.rect.x += self.speed

    def shoot(self):
        bullet = pygame.Rect(self.rect.centerx, self.rect.top, BULLET_WIDTH, BULLET_HEIGHT)
        self.bullets.append(bullet)

    def draw(self):
        pygame.draw.rect(screen, WHITE, self.rect)
        for bullet in self.bullets:
            pygame.draw.rect(screen, RED, bullet)


class Enemy:
    def __init__(self, x, y):
        self.rect = pygame.Rect(x, y, ENEMY_WIDTH, ENEMY_HEIGHT)
        self.speed = 2

    def move(self):
        self.rect.y += self.speed

    def draw(self):
        pygame.draw.rect(screen, (0, 255, 0), self.rect)


def draw_ui(player, score):
    health_text = font.render(f"Health: {player.health}", True, WHITE)
    score_text = font.render(f"Score: {score}", True, WHITE)
    screen.blit(health_text, (10, 10))
    screen.blit(score_text, (WIDTH - 120, 10))


def main():
    player = Player()
    enemies = []
    score = 0
    enemy_spawn_timer = 0
    running = True

    while running:
        clock.tick(FPS)
        screen.fill(BLACK)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    player.shoot()

        keys = pygame.key.get_pressed()
        player.move(keys)

        # Update bullets
        for bullet in player.bullets[:]:
            bullet.y -= 10
            if bullet.bottom < 0:
                player.bullets.remove(bullet)

        # Spawn enemies
        enemy_spawn_timer += 1
        if enemy_spawn_timer > 40:
            x = random.randint(0, WIDTH - ENEMY_WIDTH)
            enemies.append(Enemy(x, 0))
            enemy_spawn_timer = 0

        # Update enemies
        for enemy in enemies[:]:
            enemy.move()
            if enemy.rect.top > HEIGHT:
                enemies.remove(enemy)
                player.health -= 1
            for bullet in player.bullets[:]:
                if enemy.rect.colliderect(bullet):
                    enemies.remove(enemy)
                    player.bullets.remove(bullet)
                    score += 1
                    break

        # Check game over
        if player.health <= 0:
            game_over_text = font.render("Game Over! Press R to Restart", True, WHITE)
            screen.blit(game_over_text, (WIDTH // 2 - 150, HEIGHT // 2))
            pygame.display.flip()
            pygame.time.wait(2000)
            main()
            return

        # Draw
        player.draw()
        for enemy in enemies:
            enemy.draw()
        draw_ui(player, score)

        pygame.display.flip()

    pygame.quit()
    sys.exit()


if __name__ == "__main__":
    main()
